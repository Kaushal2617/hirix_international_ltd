import React, { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Edit, Trash, Check, Eye, EyeOff, XCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { ProductDetailsForm, ProductFormData } from "./ProductDetailsForm";
import { allProducts } from "@/data/products";
// Rename the local Product type to AdminProduct to avoid import conflict.
interface AdminProduct {
  id: string;
  sku: string;
  name: string;
  category: string;
  price: number;
  material: string;
  color: string;
  image: string;
  oldPrice?: number;
  outOfStock?: boolean;
  published?: boolean;
  inventory: number;
  details?: string[]; // Added details property
}

interface ProductTableProps {
  products: AdminProduct[];
  onUpdateProduct: (updatedProduct: AdminProduct) => void;
  onDeleteProduct: (productId: string) => void;
}

export const ProductTable = ({ 
  products, 
  onUpdateProduct, 
  onDeleteProduct 
}: ProductTableProps) => {
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [discountDialogOpen, setDiscountDialogOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<AdminProduct | null>(null);
  const [editedProduct, setEditedProduct] = useState<ProductFormData | null>(null);
  const [discountAmount, setDiscountAmount] = useState("");

  const categories = Array.from(new Set(allProducts.map(p => p.category)));
  const materials = Array.from(new Set(allProducts.map(p => p.material)));
  const colors = Array.from(new Set(allProducts.map(p => p.color)));

  const handleEditClick = (product: AdminProduct) => {
    setCurrentProduct(product);
    setEditedProduct({ ...product, details: Array.isArray(product.details) ? product.details : (product.details ? [product.details] : []) });
    setEditDialogOpen(true);
  };

  const handleDiscountClick = (product: AdminProduct) => {
    setCurrentProduct(product);
    setDiscountAmount("");
    setDiscountDialogOpen(true);
  };

  const handleDeleteClick = (productId: string) => {
    const productToDelete = products.find(p => p.id === productId);
    const productName = productToDelete ? productToDelete.name : 'Product';
    
    if (window.confirm(`Are you sure you want to delete "${productName}"? This action cannot be undone.`)) {
      onDeleteProduct(productId);
      toast({
        title: "Product deleted",
        description: `${productName} has been removed from inventory`,
      });
    }
  };

  const handleSaveEdit = () => {
    if (!editedProduct) {
      toast({
        title: "Error",
        description: "No product data to save",
        variant: "destructive"
      });
      return;
    }

    // Validate required fields
    if (!editedProduct.name.trim() || !editedProduct.sku.trim() || editedProduct.price <= 0) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields with valid values",
        variant: "destructive"
      });
      return;
    }

    onUpdateProduct(editedProduct as AdminProduct);
    setEditDialogOpen(false);
    setCurrentProduct(null);
    setEditedProduct(null);
    toast({
      title: "Product updated",
      description: `${editedProduct.name} has been updated successfully`,
    });
  };

  const handleApplyDiscount = () => {
    if (!currentProduct || !discountAmount.trim()) {
      toast({
        title: "Invalid input",
        description: "Please enter a discount percentage",
        variant: "destructive",
      });
      return;
    }

    const discountPercentage = parseFloat(discountAmount);
    if (isNaN(discountPercentage) || discountPercentage < 0 || discountPercentage > 100) {
      toast({
        title: "Invalid discount",
        description: "Please enter a valid discount percentage between 0 and 100",
        variant: "destructive",
      });
      return;
    }

    const oldPrice = currentProduct.oldPrice || currentProduct.price;
    const newPrice = oldPrice * (1 - discountPercentage / 100);
    
    const updatedProduct = {
      ...currentProduct,
      price: parseFloat(newPrice.toFixed(2)),
      oldPrice: oldPrice,
    };
    
    onUpdateProduct(updatedProduct);
    setDiscountDialogOpen(false);
    setCurrentProduct(null);
    setDiscountAmount("");
    toast({
      title: "Discount applied",
      description: `A ${discountPercentage}% discount has been applied to ${currentProduct.name}`,
    });
  };

  const handleRemoveDiscount = () => {
    if (!currentProduct || !currentProduct.oldPrice) {
      toast({
        title: "No discount to remove",
        description: "This product doesn't have an active discount",
        variant: "destructive",
      });
      return;
    }

    const updatedProduct = {
      ...currentProduct,
      price: currentProduct.oldPrice,
      oldPrice: undefined,
    };
    
    onUpdateProduct(updatedProduct);
    setDiscountDialogOpen(false);
    setCurrentProduct(null);
    setDiscountAmount("");
    toast({
      title: "Discount removed",
      description: `The discount has been removed from ${currentProduct.name}`,
    });
  };

  const handleEditInputChange = (field: keyof ProductFormData, value: string | number | string[] | boolean) => {
    if (!editedProduct) return;
    
    setEditedProduct({
      ...editedProduct,
      [field]: value
    });
  };

  return (
    <>
      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead>SKU</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Material</TableHead>
              <TableHead>Color</TableHead>
              <TableHead>Inventory</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((product) => (
              <TableRow key={product.id}>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-10 h-10 rounded object-cover"
                    />
                    <span className="font-medium">{product.name}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="font-mono text-sm">{product.sku}</span>
                </TableCell>
                <TableCell>{product.category}</TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <span>£{product.price.toFixed(2)}</span>
                    {product.oldPrice && (
                      <span className="text-xs text-muted-foreground line-through">
                        £{product.oldPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
                </TableCell>
                <TableCell>{product.material}</TableCell>
                <TableCell>{product.color}</TableCell>
                <TableCell>
                  {product.inventory === 0 ? (
                    <span className="text-xs text-red-500 font-semibold">Out of Stock</span>
                  ) : (
                    <span className="text-xs text-green-600 font-semibold">{product.inventory} in stock</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2 items-center">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleEditClick(product)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    {/* Publish Toggle */}
                    <label className="flex items-center cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={!!product.published}
                        onChange={() => onUpdateProduct({ ...product, published: !product.published })}
                        className="w-5 h-5 accent-green-500 ml-2 mr-1"
                      />
                      <span className="text-xs text-gray-600">{product.published ? "Published" : "Unpublished"}</span>
                    </label>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDeleteClick(product.id)}
                    >
                      <Trash className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Edit Product Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" aria-describedby="product-dialog-desc">
          <DialogDescription id="product-dialog-desc">Product dialog content.</DialogDescription>
          <DialogHeader>
            <DialogTitle>Edit: {currentProduct?.name}</DialogTitle>
          </DialogHeader>
          {editedProduct && (
            <div className="py-4">
              <ProductDetailsForm
                formData={editedProduct}
                onChange={handleEditInputChange}
                categories={categories}
                materials={materials}
                colors={colors}
              />
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveEdit} className="bg-red-500 hover:bg-red-600">Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Discount Dialog */}
      <Dialog open={discountDialogOpen} onOpenChange={setDiscountDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Apply Discount</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="discount" className="text-right">
                Discount (%)
              </Label>
              <Input
                id="discount"
                type="number"
                min="0"
                max="100"
                step="0.01"
                value={discountAmount}
                onChange={(e) => setDiscountAmount(e.target.value)}
                className="col-span-3"
                placeholder="Enter discount percentage"
              />
            </div>
            {currentProduct?.oldPrice && (
              <div className="text-sm text-muted-foreground">
                Current price: £{currentProduct.price.toFixed(2)} (Original: £{currentProduct.oldPrice.toFixed(2)})
              </div>
            )}
            {currentProduct && !currentProduct.oldPrice && (
              <div className="text-sm text-muted-foreground">
                Current price: £{currentProduct.price.toFixed(2)}
              </div>
            )}
          </div>
          <DialogFooter className="flex justify-between">
            {currentProduct?.oldPrice && (
              <Button variant="outline" onClick={handleRemoveDiscount}>
                Remove Discount
              </Button>
            )}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setDiscountDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleApplyDiscount}>
                <Check className="mr-2 h-4 w-4" /> Apply Discount
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
